import Navigo from 'navigo';
export declare const router: Navigo;
