export declare const ADMIN_URL = "ws://localhost:22222";
export declare const APP_URL = "ws://localhost:22223";
export declare const COMPOSITORY_DNA_HASH = "uhC0kwyu7v7v-QZolWM0C5Fl_zL5Q9XO6MaFsDKPmLVF3I9St-W97";
export declare const DOCKER_DESTKOP_URL = "https://www.docker.com/products/docker-desktop";
