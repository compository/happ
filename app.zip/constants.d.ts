export declare const ADMIN_URL = "ws://localhost:22222";
export declare const APP_URL = "ws://localhost:22223";
export declare const COMPOSITORY_DNA_HASH = "uhC0kKAzmC9d5TL59sseFlRKugw9wfBzXj_4e3oq5GJWOzVSW6jwL";
export declare const DOCKER_DESTKOP_URL = "https://www.docker.com/products/docker-desktop";
