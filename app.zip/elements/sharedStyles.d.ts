export declare const sharedStyles: import("lit-element").CSSResult;
