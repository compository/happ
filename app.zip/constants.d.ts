export declare const ADMIN_URL = "ws://localhost:22222";
export declare const APP_URL = "ws://localhost:22223";
export declare const COMPOSITORY_DNA_HASH = "uhC0klH1NAzmRGd-AKfJ6bw_yWlBxyJITwrzMqZOJ3dSKv4beYKW-";
export declare const DOCKER_DESTKOP_URL = "https://www.docker.com/products/docker-desktop";
